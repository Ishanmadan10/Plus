import SwiftUI
import PhotosUI

struct JournalToolbar: View {

    let accent: Color

    @Binding var photoItem: PhotosPickerItem?
    @Binding var selectedImage: UIImage?
    @Binding var entryText: String
    @Binding var selectedColor: Color

    let textColors: [(Color, String)]

    let onSave: () -> Void

    var body: some View {

        HStack(spacing: 12) {

            // Photo Picker
            PhotosPicker(
                selection: $photoItem,
                matching: .images
            ) {

                HStack(spacing: 5) {

                    Image(systemName: "photo")
                        .font(.system(size: 13))

                    Text("Photo")
                        .font(.system(size: 12, design: .rounded))
                }
                .foregroundColor(.white.opacity(0.55))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(.white.opacity(0.08))
                .cornerRadius(20)
            }
            .onChange(of: photoItem) {

                Task {

                    if let data = try? await photoItem?.loadTransferable(type: Data.self),
                       let img = UIImage(data: data) {

                        selectedImage = img
                    }
                }
            }

            // Mood Menu
            Menu {

                ForEach(
                    ["😊", "😐", "😔", "😤", "🥰", "😴"],
                    id: \.self
                ) { emoji in

                    Button(emoji) {
                        entryText += " \(emoji)"
                    }
                }

            } label: {

                HStack(spacing: 5) {

                    Text("☺")
                        .font(.system(size: 13))

                    Text("Mood")
                        .font(.system(size: 12, design: .rounded))
                }
                .foregroundColor(.white.opacity(0.55))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(.white.opacity(0.08))
                .cornerRadius(20)
            }

            // Colour Picker
            Menu {

                ForEach(textColors, id: \.1) { (col, _) in

                    Button {

                        selectedColor = col

                    } label: {

                        Label(
                            col == .white
                            ? "White"
                            : col == .yellow
                            ? "Yellow"
                            : col == Color(hex: "FF6B6B")
                            ? "Red"
                            : "Green",
                            systemImage: "circle.fill"
                        )
                    }
                }

            } label: {

                HStack(spacing: 5) {

                    Circle()
                        .fill(selectedColor)
                        .frame(width: 10, height: 10)

                    Text("Colour")
                        .font(.system(size: 12, design: .rounded))
                }
                .foregroundColor(.white.opacity(0.55))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(.white.opacity(0.08))
                .cornerRadius(20)
            }

            Spacer()

            // Save Button
            Button(action: onSave) {

                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: 30))
                    .foregroundColor(accent)
            }
            .disabled(
                entryText.trimmingCharacters(in: .whitespaces).isEmpty
            )
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 14)
        .background(.white.opacity(0.03))
    }
}
