import SwiftUI

struct JournalEditorView: View {

    @Binding var entryText: String
    @Binding var selectedColor: Color
    @Binding var selectedImage: UIImage?
    @Binding var savedEntries: [String]

    @FocusState var focused: Bool

    var body: some View {

        ZStack(alignment: .topLeading) {

            RoundedRectangle(cornerRadius: 20)
                .fill(Color(red: 0.1, green: 0.1, blue: 0.17))

            GeometryReader { geo in

                let lineH: CGFloat = 28
                let count = Int(geo.size.height / lineH) + 1

                VStack(spacing: 0) {

                    ForEach(0..<count, id: \.self) { _ in

                        VStack(spacing: 0) {

                            Spacer()

                            Rectangle()
                                .fill(.white.opacity(0.06))
                                .frame(height: 0.5)
                        }
                        .frame(height: lineH)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
            }

            ScrollView {

                VStack(alignment: .leading, spacing: 0) {

                    ForEach(savedEntries, id: \.self) { entry in

                        Text(entry)
                            .font(.system(size: 15, design: .rounded))
                            .foregroundColor(.white.opacity(0.8))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 20)
                            .padding(.top, 14)
                            .lineSpacing(14)
                    }

                    if let img = selectedImage {

                        Image(uiImage: img)
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                            .padding(.top, 10)
                    }

                    TextEditor(text: $entryText)
                        .scrollContentBackground(.hidden)
                        .background(.clear)
                        .foregroundColor(selectedColor)
                        .font(.system(size: 15, design: .rounded))
                        .lineSpacing(14)
                        .focused($focused)
                        .frame(minHeight: 140)
                        .padding(.horizontal, 16)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 320)
        .padding(.horizontal, 20)
    }
}
