import SwiftUI

struct PrayerCardRow: View {

    @Binding var prayer: PrayerCard
    let accent: Color
    let onDelete: () -> Void

    var body: some View {

        HStack {

            Image(systemName: prayer.icon)
                .foregroundColor(accent)

            VStack(alignment: .leading, spacing: 4) {

                Text(prayer.name)
                    .foregroundColor(.white)

                if !prayer.frequency.isEmpty {

                    Text(prayer.frequency)
                        .foregroundColor(.white.opacity(0.6))
                        .font(.caption)
                }

                if let time = prayer.time {

                    Text(time)
                        .foregroundColor(.white.opacity(0.5))
                        .font(.caption2)
                }
            }

            Spacer()

            Button(action: onDelete) {

                Image(systemName: "trash")
                    .foregroundColor(.red.opacity(0.8))
            }
        }
        .padding()
        .background(.white.opacity(0.06))
        .cornerRadius(16)
    }
}
