import SwiftUI
import PhotosUI

struct JournalSectionView: View {

    let sectionColor: String
    @ObservedObject var noteStore: NoteStore
    var onDismiss: () -> Void

    @State private var entryText = ""
    @State private var selectedColor: Color = .white
    @State private var photoItem: PhotosPickerItem? = nil
    @State private var selectedImage: UIImage? = nil
    @State private var savedEntries: [String] = []
    @FocusState private var focused: Bool

    let textColors: [(Color, String)] = [
        (.white, "FFFFFF"),
        (.yellow, "FFD60A"),
        (Color(hex: "FF6B6B"), "FF6B6B"),
        (Color(hex: "69DB7C"), "69DB7C")
    ]

    var accent: Color {
        Color(hex: sectionColor)
    }

    private var dateLabel: String {
        let f = DateFormatter()
        f.dateFormat = "d MMM yyyy"
        return f.string(from: Date()).uppercased()
    }

    var body: some View {

        ZStack {

            Color(red: 0.08, green: 0.08, blue: 0.14)
                .ignoresSafeArea()

            VStack(spacing: 0) {

                SectionHeader(
                    icon: "notebook",
                    title: "Journal",
                    accentColor: accent,
                    onDismiss: onDismiss
                )

                Text(dateLabel)
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .tracking(2)
                    .foregroundColor(.white.opacity(0.35))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 12)

                JournalEditorView(
                    entryText: $entryText,
                    selectedColor: $selectedColor,
                    selectedImage: $selectedImage,
                    savedEntries: $savedEntries,
                    focused: _focused
                )

                Spacer(minLength: 0)

                JournalToolbar(
                    accent: accent,
                    photoItem: $photoItem,
                    selectedImage: $selectedImage,
                    entryText: $entryText,
                    selectedColor: $selectedColor,
                    textColors: textColors,
                    onSave: saveEntry
                )
            }
        }
        .onAppear {
            let entries = noteStore.notes(for: "Journal")

            if let today = entries.first(where: { $0.title == dateLabel }) {
                savedEntries = today.content
                    .components(separatedBy: "\n")
                    .filter { !$0.isEmpty }
            }
        }
    }

    private func saveEntry() {

        let t = entryText.trimmingCharacters(in: .whitespaces)

        guard !t.isEmpty else { return }

        withAnimation {
            savedEntries.append(t)
        }

        entryText = ""

        let note = Note(
            title: dateLabel,
            content: savedEntries.joined(separator: "\n"),
            sectionName: "Journal"
        )

        noteStore.save(note: note)
    }
}
