import SwiftUI

struct GenericNotesTab: View {

    let sectionName: String
    let accentColor: Color

    @ObservedObject var noteStore: NoteStore

    @Binding var showNotesList: Bool
    @Binding var showNoteEditor: Bool

    @Binding var editingNote: Note?

    var body: some View {

        VStack(spacing: 12) {

            HStack(spacing: 10) {

                Button {

                    editingNote = nil
                    showNoteEditor = true

                } label: {

                    HStack(spacing: 6) {

                        Image(systemName: "square.and.pencil")
                            .font(.system(size: 14))

                        Text("New note")
                            .font(
                                .system(
                                    size: 14,
                                    weight: .medium,
                                    design: .rounded
                                )
                            )
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(accentColor.opacity(0.3))
                    .cornerRadius(14)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(
                                accentColor.opacity(0.5),
                                lineWidth: 1
                            )
                    )
                }

                Button {

                    showNotesList = true

                } label: {

                    HStack(spacing: 6) {

                        Image(systemName: "list.bullet")
                            .font(.system(size: 14))

                        Text("All notes")
                            .font(
                                .system(
                                    size: 14,
                                    weight: .medium,
                                    design: .rounded
                                )
                            )
                    }
                    .foregroundColor(.white.opacity(0.7))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(.white.opacity(0.08))
                    .cornerRadius(14)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(
                                .white.opacity(0.12),
                                lineWidth: 1
                            )
                    )
                }
            }
            .padding(.horizontal, 20)

            let recentNotes = noteStore.notes(for: sectionName)

            if recentNotes.isEmpty {

                EmptyNotesView()

            } else {

                ScrollView {

                    VStack(spacing: 10) {

                        ForEach(recentNotes.prefix(5)) { note in

                            RecentNoteCard(
                                note: note,
                                onTap: {
                                    editingNote = note
                                    showNoteEditor = true
                                }
                            )
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }
            }
        }
    }
}
